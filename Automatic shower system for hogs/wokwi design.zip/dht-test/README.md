Setup:

Clone the repository
`git clone https://github.com/Bodey001/dht-test`

Download the extensions
C/C++
Wokwi Simulator
PlatformIO IDE

Build the ./src/main.cpp file

Run the simulation in diagram.json file